package com.example.mobile;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Adapter extends RecyclerView.Adapter<Adapter.AdapterViewHolder> {
    private Context ctx;
    private ArrayList<Variables> mArraylist;
    private OnItemClickListner mLister;

    public interface OnItemClickListner{
        void onItemClick(int position);
    }

    public void setOnItemClickListner(OnItemClickListner listner){
        mLister = listner;
    }

    public Adapter(Context ctx, ArrayList<Variables> mArraylist) {
        this.ctx = ctx;
        this.mArraylist = mArraylist;
    }

    @NonNull
    @Override
    public AdapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(ctx).inflate(R.layout.card_layout, parent, false);

        return new AdapterViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterViewHolder holder, int position) {
        Variables variables = mArraylist.get(position);


        String pinlevel = variables.getPinlevel();

        String rec_pinlevel = variables.getPinlevel();
        String waterlevel = variables.getWaterlevel();
        String status = variables.getStatus();
        String date = variables.getDate();

        holder.pinlevel.setText(pinlevel);
        holder.waterlevel.setText(waterlevel);
        holder.status.setText(status);
        holder.date.setText(date);
    }

    @Override
    public int getItemCount()
    {
        return mArraylist.size();
    }

    public class AdapterViewHolder extends RecyclerView.ViewHolder{

        TextView pinlevel, waterlevel, status ,date;

        public AdapterViewHolder(@NonNull View itemView) {
            super( itemView );

            pinlevel = itemView.findViewById(R.id.print_pinlevel);
            waterlevel = itemView.findViewById(R.id.print_waterlevel);
            status = itemView.findViewById(R.id.print_status);
            date = itemView.findViewById(R.id.print_date);

            itemView.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(mLister != null){
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            mLister.onItemClick(position);
                        }
                    }
                }
            } );
        }
    }
}