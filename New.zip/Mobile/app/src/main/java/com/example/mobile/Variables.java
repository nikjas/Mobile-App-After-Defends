package com.example.mobile;

public class Variables {
    private String pinlevel;
    private String waterlevel;
    private String status;
    private String date;

    public Variables(String pinlevel, String waterlevel, String status, String date) {
        this.pinlevel = pinlevel;
        this.waterlevel = waterlevel;
        this.status = status;
        this.date = date;
    }

    public String getPinlevel() {
        return pinlevel;
    }

    public void setPinlevel(String pinlevel) {
        this.pinlevel = pinlevel;
    }

    public String getWaterlevel() {
        return waterlevel;
    }

    public void setWaterlevel(String waterlevel) {
        this.waterlevel = waterlevel;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}